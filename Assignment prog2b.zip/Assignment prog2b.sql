CREATE DATABASE RaceDay08;
GO

USE RaceDay08;
GO
CREATE TABLE Users(
UserID INT IDENTITY(1,1) PRIMARY KEY,
FirstName VARCHAR(50) NOT NULL,
LastName VARCHAR(50) NOT NULL,
Email VARCHAR(100) NOT NULL UNIQUE,
Password VARCHAR(100) NOT NULL,
Role VARCHAR(50) NOT NULL,
);

CREATE TABLE Events(
EventID  INT IDENTITY(1,1) PRIMARY KEY,
OrganiserID INT NOT NULL,
EventName VARCHAR(100) NOT NULL,
EventType VARCHAR(30) NOT NULL,
EventDate DATE NOT NULL,
Location VARCHAR(100) NOT NULL,
Description VARCHAR(255),
FOREIGN KEY(Organiser ID)
  REFERENCES Users(UserID)
);
CREATE TABLE Categories (
CategoryID INT IDENTITY(1,1) PRIMARY KEY,
EventID NOT NULL,
CatagoryName VARCHAR(50) NOT NULL,
Distance DECIMAL(6,2),
EntryFee DECIMAL(10,2),
FOREIGN KEY(EventID)
 REFERENCES Events(EventID)
);

CREATE TABLE Resault(
ResualtID INT IDENTITY(1,1) PRIMARY KEY,
EntryID  INT NOT NULL,
FinishTime TIME,
Position INT,
FOREIGN KEY(EntryID)
 REFERENCES Entriess(EntryID)
);

CREATE TABLE Route (
RouteID INT IDENTITY(1,1) PRIMARY KEY,
EventID NOT NULL,
RouteName VARCHAR(100) NOT NULL,
Distance DECIMAL(6,2),
RouteInformation VARCHAR(255),
FOREIGN KEY(EventID)
 REFERENCES Events(EventID)
 );
 
CREATE TABLE Weather(
WeatherID INT IDENTITY(1,1) PRIMARY KEY,
EventID NOT NULL,
Tempariture DECIMAL(5,2),
WeatherConditions VARCHAR(50),
ForecastDate DATE,
 REFERENCES Events(EventID)
FOREIGN KEY(EventID)
);
INSERT INTO Users
(FirstName, LastName, Email, Password, Role)
VALUES
('Masixole', 'Sitshetshe','masx@gmail.com', 'max09', 'organiser'),
('Tina', 'Ndwayana','max@gmail.com', 'map09', 'organiser'),
('Abongile', 'Femele','mas@gmail.com', 'ma09', 'manager');
INSERT INTO Events
(FirstName, LastName, Email, Password, Role)
(OrganiserID, EventName, EventType, EventDate,  Location, Description)
VALUES
(1, 'kwadwesi showcasing race',  'Running', '2026-11-08',  'kwadwesi', , 'Annuall running event');
INSERT INTO Categories
(EventID , CatagoryName, Distance, EntryFee)
VALUES
(3,1,1, '1019-09-01', 'Confirmed'),
(3,1,2, '1019-09-02', 'Confirmed');
INSERT INTO Resault
(EntryID, FinishTime, Position)
VALUES
('1 , ' 00:00:25' , 12),
('2, ' 02:00:25' , 12);
INSERT INTO Route
(EventID, RouteName, Distance, RouteInformation)
VALUES
(1, 'KWADWESI 16KM Route', 11.00,'Finish at the main stadium');


INSERT INTO Weather
(EventID, Tempariture, WeatherConditions, ForecastDate)
(12, 3.5, 'windy', '2026-12-08');